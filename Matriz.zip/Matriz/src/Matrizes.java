import java.util.Random;
public class Matrizes {

	public static void main(String[] args) {
		Random aleatorio = new Random();
		int mat[][] = new int [10][10];
		int tri[][]= new int [10][10];
		int acul [][]= new int [10][10];
		System.out.println("Principal e Secundaria");
		for (int i = 0; i < mat.length; i++) {
			for (int j = 0; j < mat.length; j++) {
				mat [i][j] = aleatorio.nextInt(10);

				if( (i==j)|(i+j==9))System.out.print(mat[i][j]);
					else System.out.print("*");
			} System.out.println();
		}
		System.out.println();
		System.out.println("Triangulo Inferior\n");
		for (int i = 0; i < mat.length; i++) {
			for (int j = 0; j < mat.length; j++) {
				tri [i][j] = aleatorio.nextInt(10);
				if (i>j)System.out.print(mat [i][j]);
				else System.out.print("*");
			}
			System.out.println();	
		}
		System.out.println();
		System.out.println("Triangulo Superior\n");
		for (int i = 0; i < mat.length; i++) {
			for (int j = 0; j < mat.length; j++) {
				tri [i] [j] = aleatorio.nextInt(10);
				if (i<j)System.out.print(mat[i][j]);
				else System.out.print("*");
			}
			System.out.println();
		}
		System.out.println();
		for (int i = 0; i < mat.length; i++) {
			for (int j = 0; j < mat.length; j++) {
				acul[i][j] += mat[i][j] * tri [i][j];
				System.out.print(acul[i][j]);
			}
			System.out.println();
		}
			
	}
	
}
		
	


